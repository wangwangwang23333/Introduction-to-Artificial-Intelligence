import pygame
import sys
import time
import math
import random
from numpy import array,zeros,linspace,sin,pi
from random import randint, choice
from enum import Enum
import threading
import numpy as np
from collections import deque

class MAP_ENTRY_TYPE(Enum):
	MAP_EMPTY = 0,
	MAP_BLOCK = 1,

class WALL_DIRECTION(Enum):
	WALL_LEFT = 0,
	WALL_UP = 1,
	WALL_RIGHT = 2,
	WALL_DOWN = 3,

class Map():
	def __init__(self, width, height):
		self.width = width
		self.height = height
		self.map = [[0 for x in range(self.width)] for y in range(self.height)]
	
	def resetMap(self, value):
		for y in range(self.height):
			for x in range(self.width):
				self.setMap(x, y, value)
	
	def setMap(self, x, y, value):
		if value == MAP_ENTRY_TYPE.MAP_EMPTY:
			self.map[y][x] = 0
		elif value == MAP_ENTRY_TYPE.MAP_BLOCK:
			self.map[y][x] = 1
	
	def isVisited(self, x, y):
		return self.map[y][x] != 1

	def showMap(self):
		for row in self.map:
			s = ''
			for entry in row:
				if entry == 0:
					s += ' 0'
				elif entry == 1:
					s += ' #'
				else:
					s += ' X'
			print(s)

def checkAdjacentPos(map, x, y, width, height, checklist):
	directions = []
	if x > 0:
		if not map.isVisited(2*(x-1)+1, 2*y+1):
			directions.append(WALL_DIRECTION.WALL_LEFT)
				
	if y > 0:
		if not map.isVisited(2*x+1, 2*(y-1)+1):
			directions.append(WALL_DIRECTION.WALL_UP)

	if x < width -1:
		if not map.isVisited(2*(x+1)+1, 2*y+1):
			directions.append(WALL_DIRECTION.WALL_RIGHT)
		
	if y < height -1:
		if not map.isVisited(2*x+1, 2*(y+1)+1):
			directions.append(WALL_DIRECTION.WALL_DOWN)
		
	if len(directions):
		direction = choice(directions)
		if direction == WALL_DIRECTION.WALL_LEFT:
				map.setMap(2*(x-1)+1, 2*y+1, MAP_ENTRY_TYPE.MAP_EMPTY)
				map.setMap(2*x, 2*y+1, MAP_ENTRY_TYPE.MAP_EMPTY)
				checklist.append((x-1, y))
		elif direction == WALL_DIRECTION.WALL_UP:
				map.setMap(2*x+1, 2*(y-1)+1, MAP_ENTRY_TYPE.MAP_EMPTY)
				map.setMap(2*x+1, 2*y, MAP_ENTRY_TYPE.MAP_EMPTY)
				checklist.append((x, y-1))
		elif direction == WALL_DIRECTION.WALL_RIGHT:
				map.setMap(2*(x+1)+1, 2*y+1, MAP_ENTRY_TYPE.MAP_EMPTY)
				map.setMap(2*x+2, 2*y+1, MAP_ENTRY_TYPE.MAP_EMPTY)
				checklist.append((x+1, y))
		elif direction == WALL_DIRECTION.WALL_DOWN:
			map.setMap(2*x+1, 2*(y+1)+1, MAP_ENTRY_TYPE.MAP_EMPTY)
			map.setMap(2*x+1, 2*y+2, MAP_ENTRY_TYPE.MAP_EMPTY)
			checklist.append((x, y+1))
		return True
	else:
		return False
		
def randomPrim(map, width, height):
	startX, startY = (randint(0, width-1), randint(0, height-1))
	print("start(%d, %d)" % (startX, startY))
	map.setMap(2*startX+1, 2*startY+1, MAP_ENTRY_TYPE.MAP_EMPTY)
	
	checklist = []
	checklist.append((startX, startY))
	while len(checklist):
		# select a random entry from checklist
		entry = choice(checklist)	
		if not checkAdjacentPos(map, entry[0], entry[1], width, height, checklist):
			# the entry has no unvisited adjacent entry, so remove it from checklist
			checklist.remove(entry)
			
def doRandomPrim(map):
	# set all entries of map to wall
	map.resetMap(MAP_ENTRY_TYPE.MAP_BLOCK)	
	randomPrim(map, (map.width-1)//2, (map.height-1)//2)

#迷宫信息
WIDTH = 20
HEIGHT = 20

#速度
corrSpeed=0.2
wroSpeed=0.1

map = Map(WIDTH, HEIGHT)
doRandomPrim(map)
map.showMap()

#起始位置
startX=1
startY=1

#结束位置
endX=HEIGHT-3
endY=WIDTH-3

#当前位置
x=1
y=1

#方格大小
WALL_SIZE=30

#当前状态
stateStop=False
findWay=False
nextStep=False

#线程
threadPool=[]

#强制中断线程
stopThread=False

#pygame初始化
pygame.init()
pygame.font.init()
screen=pygame.display.set_mode((WALL_SIZE*WIDTH+150,WALL_SIZE*HEIGHT+10),0,32)
font = pygame.font.SysFont("Arial", 50)
pygame.display.set_caption('人工智能导论————搜索算法演示')

#加载相关素材
background=pygame.image.load("background.jpg")
wallPic=pygame.image.load("wall.png")
rouPic=pygame.image.load("routine.png")
probleRouPic=pygame.image.load("check.png")
desPic=pygame.image.load("destination.png")
heroPic=pygame.image.load("hero.png")
stopPic=pygame.image.load("stop.png")
continuePic=pygame.image.load("continue.png")
dfsPic=pygame.image.load("dfs.png") #90x40
bfsPic=pygame.image.load("bfs.png") #90x40
bestFirstPic=pygame.image.load("bestFirst.png") #90x40
AstarPic=pygame.image.load("Astar.png") #90x40
nextPic=pygame.image.load("next.png")#50x50
HillPic=pygame.image.load("HillClimbing.png") #90x40
funcSinPic=pygame.image.load("FunSinx.png") #90x40
funcSinxPic=pygame.image.load("FuncSinxx.png") #90x40

toolTip=""

#当前演示状态
showState=0

#是否前往过
visited=zeros((HEIGHT,WIDTH))
visited[startX][startY]=1

#循环状态判断
def isWaiting():
    global nextStep,stateStop,wroSpeed
    while stateStop:
        #nextStep按下的话，执行一次操作
        if nextStep:
            nextStep=False
            break
        time.sleep(wroSpeed)

#bfs,A-star,Best-First 相关变量
dist = [[999999 for _ in range(WIDTH)] for _ in range(HEIGHT)]
pre = [[None for _ in range(WIDTH)] for _ in range(HEIGHT)]
checkBfs = [[0 for _ in range(WIDTH)] for _ in range(HEIGHT)]

#bfs算法
def bfs():
    global map,x,y,startX,startY,endX,endY
    global dist,pre,checkBfs
      
    #四个方向
    dx=[1,0,-1,0]
    dy=[0,1,0,-1]

    #通过队列存储路径信息
    queue=deque()
    queue.append([x,y])
    
    while queue:
        curr=queue.popleft()
        find=False

        #为了呈现效果，只有当四个方向至少有一个方向可走
        #才会暂停一下
        canReachOne=False
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0:
                canReachOne=True
                break
        if stopThread:
            return

        if canReachOne:
            isWaiting() #stop
            time.sleep(wroSpeed)
  
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0: #可通行
                dist[nx][ny]=dist[curr[0]][curr[1]]+1
                pre[nx][ny]=curr
                checkBfs[nx][ny]=1
                queue.append([nx,ny])
                if nx==endX and ny==endY:
                    find=True
                    break
        if find:
            print("bfs successfully")
            break
    
    #此处找到
    stack = []
    curr = [endX,endY]
    while True:
        stack.append(curr)
        if curr[0] == startX and curr[1] == startY:
            break
        prev = pre[curr[0]][curr[1]]
        curr = prev
    global visited
    while stack:
        curr = stack.pop()
        #显示正确路径
        visited[curr[0]][curr[1]]=1
        print('(%d, %d)' % (curr[0], curr[1]))
        x=curr[0]
        y=curr[1]
        if stopThread:
            return
        isWaiting() #stop
        time.sleep(corrSpeed)

    global findWay
    findWay=True

#dfs算法
def dfs():
    #dfs之前要做的是更新画面
    global corrSpeed,wroSpeed
    global visited
    global map,endX,endY
    global x,y
    global findWay
    global stateStop
    global checkBfs

    #到达目的地
    if x==endX and y==endY:
        #完成
        findWay=True
        return
    #向四个方向尝试
    #right
    print("doing")
    if map.map[x][y+1]==0 and visited[x][y+1]==0:
        isWaiting() #stop 
        visited[x][y+1]=1
        checkBfs[x][y+1]=1
        y+=1
        if stopThread:
            return
        time.sleep(corrSpeed)
        dfs()
        if findWay or stopThread:
            return
        isWaiting() #stop 
        y-=1
        visited[x][y+1]=0
        time.sleep(wroSpeed)
    #left
    if map.map[x][y-1]==0 and visited[x][y-1]==0:
        isWaiting() #stop 
        visited[x][y-1]=1
        checkBfs[x][y-1]=1
        y-=1
        if stopThread:
            return
        time.sleep(corrSpeed)
        dfs()
        if findWay or stopThread:
            return
        isWaiting() #stop 
        y+=1
        visited[x][y-1]=0
        time.sleep(wroSpeed)
    #up
    if map.map[x-1][y]==0 and visited[x-1][y]==0:
        isWaiting() #stop 
        visited[x-1][y]=1
        checkBfs[x-1][y]=1
        x-=1
        if stopThread:
            return
        time.sleep(corrSpeed)
        dfs()
        if findWay or stopThread:
            return
        isWaiting() #stop 
        x+=1
        visited[x-1][y]=0
        time.sleep(wroSpeed)
    #down
    if map.map[x+1][y]==0 and visited[x+1][y]==0:
        isWaiting() #stop 
        visited[x+1][y]=1
        checkBfs[x+1][y]=1
        x+=1
        if stopThread:
            return
        time.sleep(corrSpeed)
        dfs()
        if findWay or stopThread:
            return
        isWaiting() #stop 
        x-=1
        visited[x+1][y]=0
        time.sleep(wroSpeed)

    return

#代价函数的计算
def price(currX,currY)->int:
    global endX,endY
    #计算曼哈顿距离
    return abs(endX-currX)+abs(endY-currY)

#最佳优先搜索
def bestFirstSearch():
    global map,x,y,startX,startY,endX,endY
    global dist,pre,checkBfs

    #建立openList
    openList=[]
    #加入初始点
    openList.append([startX,startY,price(startX,startY)])
    
    dx,dy=[1,0,-1,0],[0,1,0,-1]

    #不为空
    while openList:
        #根据代价进行排序
        openList.sort(key=lambda x:(x[2],abs(x[1]-x[0])))
        print(openList)
        curr=openList.pop(0)[:-1]
        find=False

        #为了呈现效果，只有当四个方向至少有一个方向可走
        #才会暂停一下
        canReachOne=False
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0:
                canReachOne=True
                break
        if stopThread:
            return

        if canReachOne:
            isWaiting() #stop
            time.sleep(wroSpeed)
  
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0: #可通行
                dist[nx][ny]=dist[curr[0]][curr[1]]+1
                pre[nx][ny]=curr
                checkBfs[nx][ny]=1
                openList.append([nx,ny,price(nx,ny)])
                if nx==endX and ny==endY:
                    find=True
                    break
        if find:
            print("Best First Search successfully")
            break

    #此处找到
    stack = []
    curr = [endX,endY]
    while True:
        stack.append(curr)
        if curr[0] == startX and curr[1] == startY:
            break
        prev = pre[curr[0]][curr[1]]
        curr = prev
    global visited
    while stack:
        curr = stack.pop()
        #显示正确路径
        visited[curr[0]][curr[1]]=1
        print('(%d, %d)' % (curr[0], curr[1]))
        x=curr[0]
        y=curr[1]
        if stopThread:
            return
        isWaiting() #stop
        time.sleep(corrSpeed)

    global findWay
    findWay=True

#A*搜索
def AStartSearch():
    global map,x,y,startX,startY,endX,endY
    global dist,pre,checkBfs

    #建立openList
    openList=[]
    #加入初始点
    openList.append([startX,startY,price(startX,startY)])
    
    dx,dy=[1,0,-1,0],[0,1,0,-1]

    #不为空
    while openList:
        #根据代价进行排序
        openList.sort(key=lambda x:(x[2],abs(x[1]-x[0])))
        print(openList)
        curr=openList.pop(0)[:-1]
        find=False

        #为了呈现效果，只有当四个方向至少有一个方向可走
        #才会暂停一下
        canReachOne=False
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0:
                canReachOne=True
                break
        if stopThread:
            return

        if canReachOne:
            isWaiting() #stop
            time.sleep(wroSpeed)
  
        for i in range(4):
            nx,ny=curr[0]+dx[i],curr[1]+dy[i]
            if map.map[nx][ny]==0 and checkBfs[nx][ny]==0: #可通行
                dist[nx][ny]=dist[curr[0]][curr[1]]+1
                pre[nx][ny]=curr
                checkBfs[nx][ny]=1
                openList.append([nx,ny,math.sqrt((nx-endX)*(nx-endX)+(ny-endY)*(ny-endY))+dist[nx][ny]])
                if nx==endX and ny==endY:
                    find=True
                    break
        if find:
            print("AStar successfully")
            break

    #此处找到
    stack = []
    curr = [endX,endY]
    while True:
        stack.append(curr)
        if curr[0] == startX and curr[1] == startY:
            break
        prev = pre[curr[0]][curr[1]]
        curr = prev
    global visited
    while stack:
        curr = stack.pop()
        #显示正确路径
        visited[curr[0]][curr[1]]=1
        print('(%d, %d)' % (curr[0], curr[1]))
        x=curr[0]
        y=curr[1]
        if stopThread:
            return
        isWaiting() #stop
        time.sleep(corrSpeed)

    global findWay
    findWay=True

#爬山法中的x坐标
hillX=0
hillMinX=0
hillMinY=0
hillFunc=math.sin
hillMaxFunc=1
hillFuncType=0
#爬山法
def hillClimbing(f,a:float,b:float,rxMax=0.01):
    #随机选[a,b]中的一个值作为初始值
    global hillX,hillMinX,hillMinY,hillFunc
    hillMinX,hillMinY,hillFunc=a,b,f

    hillX=random.random()*(b-a)+a
    rx=rxMax*random.random() #通过固定值*浮点数，实现随机浮动
    while (f(hillX)<f(hillX+rx) and f(hillX)>f(hillX-rx)) or (f(hillX)>f(hillX+rx) and f(hillX)<f(hillX-rx)):
        if f(hillX)<f(hillX+rx):
            hillX+=rx #随机数*最大值，即控制了随机数的范围
        else:
            hillX-=rx
        rx=rxMax*random.random()#更新rx的值
        time.sleep(wroSpeed/4)
        isWaiting()
    #至此，爬山法完成

#模拟退火算法
def simulatedAnaling(s0,E,kmax,emax,neighbor):
    s=s0
    e=E(s) #初始状态s0,能量E(s0)
    k=0#评估次数k
    while k<kmax and e>emax:#若还有时间（评估次数k还不到kmax）且结果还不够好（能量e不够低）
        sn=neighbor(s)#随机选取临近状态sn
        en=E(sn)#sn的能量值为en
        if en<sn or random.random()/k > 0.1:
            #最优解或者差解但是概率接受该差解
            s,e=sn,en
            k+=1
    return s#返回状态s

#画面更新
def update(findDist=False,caption=''):
    global map,wallPic,background,wallPic,WALL_SIZE,rouPic,desPic,heroPic,endX,endY
    global visited
    global x,y
    
    global stateStop,stopPic,continuePic
    global dfsPic

    #根据map更新画面
    screen.fill((255,255,255))
    screen.blit(background,(0,0))

    #绘制暂停/继续
    if stateStop:
        screen.blit(stopPic,(WALL_SIZE*WIDTH,WALL_SIZE*HEIGHT-50))
        #stop状态下同时绘制next按钮
        screen.blit(nextPic,(WALL_SIZE*WIDTH+70,WALL_SIZE*HEIGHT-50))
    else:
        screen.blit(continuePic,(WALL_SIZE*WIDTH,WALL_SIZE*HEIGHT-50))

    #绘制方格
    if showState==0:
        for i in range(map.height-1):
            for j in range(map.width-1):
                #wall
                if map.map[i][j]==1:
                    screen.blit(wallPic,(WALL_SIZE*i,WALL_SIZE*j))
                #hero
                if x==i and y==j:
                    screen.blit(heroPic,(WALL_SIZE*i,WALL_SIZE*j))
                elif visited[i][j]==1:
                    screen.blit(rouPic,(WALL_SIZE*i,WALL_SIZE*j))
                elif checkBfs[i][j]==1:
                    screen.blit(probleRouPic,(WALL_SIZE*i,WALL_SIZE*j))
                if endX==i and endY==j:
                    screen.blit(desPic,(WALL_SIZE*i,WALL_SIZE*j))
    elif showState==1:
        #坐标转换
        #以左下角为坐标原点，将图像扩充
        #位置最大值为(WALL_SIZE*WIDTH,WALL_SIZE*HEIGHT)
        #为了清除一点，距离左边20，往右、下扩展20的单位
        #(20,20)  (WALL_SIZE*WIDTH-20,20)
        #(20,WALL_SIZE*HEIGHT-40) (WALL_SIZE*WIDTH-20,WALL_SIZE*HEIGHT-40)
        #绘制x轴
        #pygame.draw.line(screen,(0,0,0),(20,WALL_SIZE*HEIGHT-40),(WALL_SIZE*WIDTH-40,WALL_SIZE*HEIGHT-40),1)
        #绘制y轴
        pygame.draw.line(screen,(0,0,0),(20,WALL_SIZE*HEIGHT-40),(20,20))
        #绘制曲线
        posX=linspace(hillMinX,hillMinY,(WALL_SIZE*HEIGHT-60)*100)
        posY=hillFunc(posX)
        #横坐标换算
        posX=posX*(WALL_SIZE*HEIGHT-60)/(hillMinY-hillMinX)+20
        posY=WALL_SIZE*HEIGHT-40-posY*(WALL_SIZE*HEIGHT-60)/hillMaxFunc
        pos=[[posX[i],posY[i]] for i in range(len(posX))]
        #绘制曲线
        pygame.draw.aalines(screen,(255,0,0),1,pos,1)
        #绘制移动的点
        pygame.draw.circle(screen, (0,255,0), [int(hillX*(WALL_SIZE*HEIGHT-60)/(hillMinY-hillMinX)+20),int(WALL_SIZE*HEIGHT-40-hillFunc(hillX)*(WALL_SIZE*HEIGHT-60)/hillMaxFunc)], 10, 10)

        #选择函数类型
        screen.blit(funcSinPic,(10,WALL_SIZE*HEIGHT-30))
        screen.blit(funcSinxPic,(110,WALL_SIZE*HEIGHT-30))

    screen.blit(dfsPic,(WALL_SIZE*WIDTH,0))
    screen.blit(bfsPic,(WALL_SIZE*WIDTH,50))
    screen.blit(bestFirstPic,(WALL_SIZE*WIDTH,100))
    screen.blit(AstarPic,(WALL_SIZE*WIDTH,150))
    screen.blit(HillPic,(WALL_SIZE*WIDTH,200))

    #提示信息
    if findWay:
        titleText=font.render("Has reached the destination", 4, (0, 255, 0)) 
        screen.blit(titleText,(0,WALL_SIZE*HEIGHT))
    else:
        titleText=font.render(toolTip, 1, (253, 177, 6)) 
        screen.blit(titleText,(0,WALL_SIZE*HEIGHT))

    pygame.display.update()

def clear():
    #清空相关变量
    global x,y
    x=1
    y=1
    global visited
    for i in range(len(visited)):
        for j in range(len(visited[0])):
            visited[i][j]=0
    visited[x][y]=1
    global findWay
    
    #清空线程池
    global threadPool
    if len(threadPool)!=0 and findWay==False:
        pass
    findWay=False

    global nextStep
    nextStep=False

    global dist,pre,checkBfs
    dist = [[999999 for _ in range(WIDTH)] for _ in range(HEIGHT)]
    pre = [[None for _ in range(WIDTH)] for _ in range(HEIGHT)] 
    checkBfs = [[0 for _ in range(WIDTH)] for _ in range(HEIGHT)]

    global stopThread
    stopThread=True
    time.sleep(0.1)
    stopThread=False

def buttonEvent(mouseX,mouseY):
    global stateStop,threadPool,showState,hillMaxFunc,hillFuncType
    if mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+50 and mouseY>=WALL_SIZE*HEIGHT-50 and mouseY<=WALL_SIZE*HEIGHT:
        stateStop=(not stateStop )
    elif mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+90 and mouseY>=0 and mouseY<=40:
        #建立一个新线程，用来进行dfs
        clear()
        showState=0
        thread = threading.Thread(target = dfs)
        threadPool.append(thread)
        threadPool[-1].start()
    elif mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+90 and mouseY>=50 and mouseY<=90:
        #建立一个新线程，用来进行bfs
        clear()
        showState=0
        thread = threading.Thread(target = bfs)
        threadPool.append(thread)
        threadPool[-1].start()
    elif mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+90 and mouseY>=100 and mouseY<=140:
        #建立一个新线程，用来进行最佳优先搜索
        clear()
        showState=0
        thread = threading.Thread(target = bestFirstSearch)
        threadPool.append(thread)
        threadPool[-1].start()
    elif mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+90 and mouseY>=150 and mouseY<=190:
        #A-start搜索
        clear()
        showState=0
        thread = threading.Thread(target = AStartSearch)
        threadPool.append(thread)
        threadPool[-1].start()
    elif mouseX>=WALL_SIZE*WIDTH and mouseX<=WALL_SIZE*WIDTH+90 and mouseY>=200 and mouseY<=240:
        #爬山法演示
        clear()
        showState=1
        #默认
        global hillMinX,hillMinY,hillFunc,hillMaxFunc
        hillMaxFunc=1
        hillMinX,hillMinY,hillFunc=0,1,lambda x:x
    elif showState==1 and mouseX>=10 and mouseX<=100 and mouseY>=WALL_SIZE*HEIGHT-30 and mouseY<=WALL_SIZE*HEIGHT+10:
        clear()
        hillFuncType=0
        hillMaxFunc=2
        thread = threading.Thread(target = hillClimbing,args=(lambda x:sin(x)+1,0,2*pi))
        threadPool.append(thread)
        threadPool[-1].start()
    elif showState==1 and mouseX>=110 and mouseX<=200 and mouseY>=WALL_SIZE*HEIGHT-30 and mouseY<=WALL_SIZE*HEIGHT+10:
        clear()
        hillFuncType=1
        hillMaxFunc=2
        thread = threading.Thread(target = hillClimbing,args=(lambda x:np.sin(x-np.pi)/(x-np.pi)+1,0,6*np.pi))
        threadPool.append(thread)
        threadPool[-1].start()
    elif mouseX>=WALL_SIZE*WIDTH+70 and mouseX<=WALL_SIZE*WIDTH+120 and mouseY>=WALL_SIZE*HEIGHT-50 and mouseY<=WALL_SIZE*HEIGHT and stateStop:
        #下一步
        global nextStep
        nextStep=True

if __name__ == "__main__":
    while True:
        for event in pygame.event.get():
            if event.type==pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type==pygame.MOUSEBUTTONDOWN:
                #获得鼠标位置
                mouseX, mouseY = pygame.mouse.get_pos()
                buttonEvent(mouseX,mouseY)
        #更新画面
        update()
